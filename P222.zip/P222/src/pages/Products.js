 
import './Products.css';

function Products() {

var products = [
  { pid: 1,
    pname: "Smartphone",
    price: 35000,
    imglink: "https://www.top10mobileshop.com/images/top10mobiles.com/thumbnail/product/2024/08/916501267202408160751.jpg", 
    description: "Latest Android smartphone with powerful features" },

  { pid: 2, 
    pname: "Laptop",
    price: 92000,
    imglink:  
      "https://images-cdn.ubuy.co.in/646527192283946f94233e13-anmesc-laptop-15-6-1080p-full-hd.jpg",
    description: "High performance laptop for work and study" },

  { pid: 3,
    pname: "Wireless Earbuds",
    price: 15000,
    imglink:  
    "https://ptron.in/cdn/shop/files/17_5b2a0e2b-e1f9-428b-84d9-c90e22274c9d_637x.jpg?v=1692526421", 
    description: "Noise cancelling wireless earbuds" },

  { pid: 4,
    pname: "Smart Watch",
    price: 2000, 
    imglink: 
    "https://media.zid.store/296f3c09-5900-4581-a986-481c31922003/db37d4a0-3054-41a9-8a72-59b737297125-260x260.png", 
    description: "Fitness tracking smart watch with heart rate monitor" },

  { pid: 5,
    pname: "Bluetooth Speaker",
    price: 5500, 
    imglink: 
    "https://rukminim2.flixcart.com/image/480/640/xif0q/speaker/tower-speaker/e/i/r/ng-p87-wireless-bluetooth-speaker-with-usb-fm-quillquarry-original-imah45wavvqq4zkh.jpeg?q=90",
    description: "Portable Bluetooth speaker with deep bass" },

  { pid: 6, 
    pname: "Headphones",
    price: 2800,
    imglink:
    "https://i.ebayimg.com/images/g/tcgAAOSwflBnY1y0/s-l300.jpg",
    description: "Over-ear wired headphones with clear sound" },

  { pid: 7,
    pname: "Keyboard", 
    price: 900, 
    imglink: 
    "https://static.vecteezy.com/system/resources/thumbnails/070/161/775/small/a-sleek-modern-black-computer-keyboard-resting-on-a-crisp-white-desk-showcasing-its-minimalist-design-for-technology-and-office-environments-photo.jpg",
    description: "USB keyboard with smooth keys" },

  { pid: 8,
    pname: "Mouse",
    price: 1200, 
    imglink:  
    "https://www.shutterstock.com/image-photo/black-illuminated-gaming-computer-mouse-260nw-2502851191.jpg",
    description: "Optical mouse suitable for daily use" },

  { pid: 9,
    pname: "Monitor",
    price: 80000,
    imglink:  
    "https://5.imimg.com/data5/KO/HU/MY-41600229/sony-tv-500x500.jpg",
    description: "24-inch Full HD LED monitor" },

  { pid: 10,
    pname: "Printer", 
    price: 40000, 
    imglink: 
    "https://t3.ftcdn.net/jpg/00/47/60/56/360_F_47605693_cexVD7JiWOJTlwQ7JfoqWhCuHU0dKd1n.jpg",
    description: "All-in-one inkjet printer" },

  { pid: 11, 
    pname: "Tablet",
    price: 88000,
    imglink:  
    "https://images.unsplash.com/photo-1623126908029-58cb08a2b272?fm=jpg&q=60&w=3000&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8dGFibGV0fGVufDB8fDB8fHww",
    description: "Lightweight tablet for entertainment and learning" },

  { pid: 12,
    pname: "Power Bank",
    price: 1500,
    imglink:  
    "https://www.shutterstock.com/image-vector/3d-power-bank-flat-illustration-260nw-2347297301.jpg",
    description: "10000mAh fast charging power bank" },

  { pid: 13, 
    pname: "External Hard Drive",
    price: 5000,
    imglink: 
    "https://static.vecteezy.com/system/resources/thumbnails/007/387/421/small/external-hdd-on-white-background-photo.jpg",
    description: "1TB portable external hard drive" },

  { pid: 14,
    pname: "Webcam",
    price: 2200,
    imglink: 
    "https://images.unsplash.com/photo-1726127461372-547b9ffa4236?fm=jpg&q=60&w=3000&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8d2ViJTIwY2FtfGVufDB8fDB8fHww",
    description: "HD webcam for online meetings" },

  { pid: 15,
    pname: "Router",
    price: 3200, 
    imglink: 
    "https://t3.ftcdn.net/jpg/02/86/00/50/360_F_286005066_jjAYqVl95Kw1eD6GMWoCSqi9OjgD8WSh.jpg",
    description: "High-speed WiFi router" },

  { pid: 16,
    pname: "USB Flash Drive",
    price: 700,
    imglink:
    "https://t4.ftcdn.net/jpg/16/81/13/47/360_F_1681134754_VBC7rbB4TsWDdFUs3VdepMoQw2mszFrF.jpg",
    description: "64GB USB 3.0 flash drive" },

  { pid: 17,
    pname: "Charger",
    price: 800,  
    imglink:  
    "https://t4.ftcdn.net/jpg/03/85/34/27/360_F_385342760_L0T7b4w07Z0qbcQKgkczpoHvzO1AU1Bg.jpg",
    description: "Fast charging mobile charger" },

  { pid: 18,
    pname: "Camera",
    price: 60000,
    imglink:
    "https://www.adorama.com/images/Large/ICAM100WK.JPG", 
    description: "Digital camera with HD video recording" },

  { pid: 19,
    pname: "Tripod",
    price: 1200,
    imglink: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRxlBUAlujexs1Ikc-ttGDm_tr2SgEKIR3AHg&s",
    description: "Adjustable tripod for camera and mobile" },

  { pid: 20,
    pname: "Microphone", 
    price: 3500,
    imglink: "https://media.istockphoto.com/id/2172371718/photo/studio-microphones.jpg?s=612x612&w=0&k=20&c=_5B6uufh_-B_9D0j2j_kkKrM3ea2OuDKXPZSmh-ueVo=",
    description: "Condenser microphone for recording and streaming" }
];

  return (
    <div  className="page">
      <h1 className="products-title"></h1>
      <div className="products-grid">
        {products.map((pro)=>{
            return(
               <div className="product-card" key={pro.pid}>
                <img src={pro.imglink} alt={pro.pname} />
                <h2>{pro.pname}</h2>
                <p>{pro.description}</p>
                <h3>{pro.price}</h3>
                 <button>Buy Now</button>
               </div>
             
            )
        })}
      </div>
           
    </div>
  );
}

export default Products;