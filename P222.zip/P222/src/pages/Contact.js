import './Contact.css';

function Contact() {
  return (
    <div className="contact-container">
    <div className="contact-box">
      <h2>Contact Us</h2>
      <p>Email: support@electroshop.com</p>
      <p>Phone: +91 9876543210</p>
    </div>
    </div>
  );
}

export default Contact;
