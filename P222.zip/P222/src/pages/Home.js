import './Home.css';

function Home() {
  return (
    <div className="home">
      <h1>Welcome to ElectroShop </h1>
      <p>Your one-stop electronics store</p>
    </div>
  );
}

export default Home;
