import { Link } from "react-router-dom";
import './Navbar.css';

function Navbar() {
  return (
     

      <div className="nav-links">
         {/* <h2>ElectroShop</h2> */}
        <Link to="/" className="a">Home</Link>
        <Link to="/login" className="a">Login</Link>
        <Link to="/products" className="a">Products</Link>
        <Link to="/contact" className="a">Contact</Link>
      </div>
   
  );
}

export default Navbar;
